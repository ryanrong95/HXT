module.exports = {
    // 就是导出一个对象，NODE_ENV是一个环境变量，指定production环境
    urltest: "/",
    mjurl:"/",
      //pfwms:"http://hv.warehouse.b1b.com",//本地开发
      //pfwms:"http://warehouse0.ic360.cn",//测试版本
      pfwms:"http://warehouse.for-ic.net:60077",//云服务器 正式版本
}
